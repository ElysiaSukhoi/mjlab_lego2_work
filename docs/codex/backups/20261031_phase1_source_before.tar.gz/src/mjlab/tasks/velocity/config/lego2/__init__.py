from mjlab.tasks.registry import register_mjlab_task
from mjlab.tasks.velocity.rl import VelocityOnPolicyRunner

from .env_cfgs import (
  lego2_flat_env_cfg,
  lego2_rough_env_cfg,
)
from .platform_climb_env_cfg import lego2_platform_climb_env_cfg
from .rl_cfg import lego2_ppo_runner_cfg

register_mjlab_task(
  task_id="Mjlab-Velocity-Rough-Lego2",
  env_cfg=lego2_rough_env_cfg(),
  play_env_cfg=lego2_rough_env_cfg(play=True),
  rl_cfg=lego2_ppo_runner_cfg(experiment_name="lego2_velocity/rough"),
  runner_cls=VelocityOnPolicyRunner,
)

register_mjlab_task(
  task_id="Mjlab-Velocity-Flat-Lego2",
  env_cfg=lego2_flat_env_cfg(),
  play_env_cfg=lego2_flat_env_cfg(play=True),
  rl_cfg=lego2_ppo_runner_cfg(experiment_name="lego2_velocity/flat"),
  runner_cls=VelocityOnPolicyRunner,
)

register_mjlab_task(
  task_id="Mjlab-Platform-Climb-Lego2",
  env_cfg=lego2_platform_climb_env_cfg(),
  play_env_cfg=lego2_platform_climb_env_cfg(play=True),
  rl_cfg=lego2_ppo_runner_cfg(experiment_name="lego2_platform_climb"),
  runner_cls=VelocityOnPolicyRunner,
)
