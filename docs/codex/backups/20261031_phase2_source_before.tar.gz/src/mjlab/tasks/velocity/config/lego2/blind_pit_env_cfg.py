"""Blind Lego2 observations, stage 1 scaffold (not yet ready for training).

Terrain, resets, commands, curriculum and rewards still inherit Rough pending
stages 2/3. The old tasks retain their observation definitions and checkpoints.
"""

from copy import deepcopy

from mjlab.envs import ManagerBasedRlEnvCfg

from .env_cfgs import lego2_rough_env_cfg

_PROPRIOCEPTION = ("base_ang_vel", "projected_gravity", "joint_pos", "joint_vel")
_ACTOR_TERMS = (*_PROPRIOCEPTION, "actions", "command")


def lego2_blind_pit_env_cfg(play: bool = False) -> ManagerBasedRlEnvCfg:
  """Use five proprioceptive frames and current action/command, term-major.

  Train/play share one factory. Avoid Rough's play-only terrain, command and
  termination overrides; only actor corruption changes for playback here.
  """
  cfg = deepcopy(lego2_rough_env_cfg(play=False))
  # The base factory shares some term objects across actor and critic. Copy
  # each group independently before setting actor history or removing terms.
  actor = deepcopy(cfg.observations["actor"])
  critic = deepcopy(cfg.observations["critic"])
  actor.terms = {name: actor.terms[name] for name in _ACTOR_TERMS}
  actor.history_length = None
  actor.flatten_history_dim = True
  actor.concatenate_terms = True
  actor.enable_corruption = not play
  for name, term in actor.terms.items():
    term.history_length = 5 if name in _PROPRIOCEPTION else 0
    term.flatten_history_dim = True
  cfg.observations = {"actor": actor, "critic": critic}
  return cfg
