"""Isolated reward-v2 candidate; the original blind-pit task stays at v1."""

from mjlab.envs import ManagerBasedRlEnvCfg
from mjlab.managers import MetricsTermCfg, RewardTermCfg

from .blind_pit_curriculums import nonfoot_contact_count
from .blind_pit_env_cfg import lego2_blind_pit_env_cfg, lego2_blind_pit_eval_cfg
from .blind_pit_rewards import (
  base_clearance_below_minimum,
  base_clearance_eligible,
  minimum_base_clearance_l2,
  pitch_relaxed_orientation_l2,
)


def _with_reward_v2(cfg: ManagerBasedRlEnvCfg) -> ManagerBasedRlEnvCfg:
  # 只修改新工厂返回的独立配置；旧任务11项基线和旧模型回放保持可用。
  # v2是一组待训练验证的姿态/净空候选，不把用户因果假设记成已证实结论。
  cfg.rewards.pop("flat_orientation_l2")
  cfg.rewards["pitch_relaxed_orientation_l2"] = RewardTermCfg(
    func=pitch_relaxed_orientation_l2,
    weight=-0.5,
    params={"free_pitch_deg": 25.0},
  )
  # 计数的是非轮碰撞geom通道，接触力范数>1 N；不因倾倒而缩小惩罚。
  # 允许轮子离地/摆动，不加入强制四轮贴地或指定前后腿动作的奖励。
  cfg.rewards["nonfoot_contact"] = RewardTermCfg(
    func=nonfoot_contact_count, weight=-0.5
  )
  clearance_params = {
    "sensor_name": "terrain_scan",
    "minimum_height": 0.34,
    "max_ground_relief": 0.03,
  }
  cfg.rewards["minimum_base_clearance_l2"] = RewardTermCfg(
    func=minimum_base_clearance_l2, weight=-2.0, params=clearance_params.copy()
  )
  # 同时记录高度项可用率与低净空帧占比，避免把跨台沿时关闭高度项误读为改善。
  cfg.metrics["base_clearance_eligible"] = MetricsTermCfg(
    func=base_clearance_eligible,
    params={"sensor_name": "terrain_scan", "max_ground_relief": 0.03},
  )
  cfg.metrics["base_clearance_below_minimum"] = MetricsTermCfg(
    func=base_clearance_below_minimum, params=clearance_params.copy()
  )
  return cfg


def lego2_blind_pit_reward_v2_env_cfg(play: bool = False) -> ManagerBasedRlEnvCfg:
  # 保留原10级高度课程、出生/命令、传感器、观测、动作及终止/通过判据。
  return _with_reward_v2(lego2_blind_pit_env_cfg(play=play))


def lego2_blind_pit_reward_v2_eval_cfg(
  height: float, forward_speed: float | None = None
) -> ManagerBasedRlEnvCfg:
  # 固定高度工厂仍生成真实指定坑深；不把关闭课程等同于固定30 cm。
  return _with_reward_v2(lego2_blind_pit_eval_cfg(height, forward_speed))
